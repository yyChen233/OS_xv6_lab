#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void work(int p[2])
{
	close(p[1]);
	int num;
	read(p[0],&num,4);
	fprintf(0,"prime %d\n",num);

	int temp;
	int q[2];

	if(read(p[0],&temp,4)!=0)
	{
		pipe(q);
		if(fork()!=0)
		{
			//parent
			close(q[0]);
			do
			{
				if(temp%num!=0)
					write(q[1],&temp,4);
			}while(read(p[0],&temp,4)!=0);
			close(p[0]);
			close(q[1]);
			wait(0);
		}
		else
		{
			work(q);
		}
	}
	return;
}


int
main(int argc, const char* argv[])
{
	int p[2];
	pipe(p);
	if(fork()!=0)
	{
		//parent
		close(p[0]);
		for(int i=2;i<=35;i++)
		{
			write(p[1],&i,4);
		}
		close(p[1]);
		wait(0);
	}
	else
	{
		work(p);
	}
	exit(0);
}
