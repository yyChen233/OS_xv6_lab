#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"

int
main(int argc,char* argv[])
{
	if(argc<2)
	{
		fprintf(2,"xargs: too little parameters\n");
		exit(1);
	}	

	char buf[512]={0};
	char* new[MAXARG]={0};
	for(int i=1;i<argc;++i)
		new[i-1]=argv[i];
	char* p;
	p=buf;
	while(read(0,p,1))
	{
		if(*p != '\n')
		{
			p++;
		}
		else
		{
			*p=0;
			new[argc-1]=buf;
			p=buf;
			if(fork()!=0)
				wait(0);
			else
				exec(argv[1],new);
		}
	}
	exit(0);
}

