#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, const char *argv[])
{
	int p[2];//pipe fd
	pipe(p);
	int q[2];//pipe fd;
	pipe(q);
	int childPid;
	if((childPid=fork())!=0)
	{	
		//parent
		int myPid=getpid();
		write(p[1],"A",1);
		close(p[0]);
		close(p[1]);
		close(q[1]);
		char b[1];
		read(q[0],b,1);
		fprintf(0,"%d: received pong\n",myPid);

	}
	else
	{
		//child
		int myPid=getpid();
		close(p[1]);
		char a[1];
		read(p[0],a,1);
		fprintf(0,"%d: received ping\n",myPid);
		close(p[0]);
		write(q[1],"B",1);
		close(q[1]);
		close(q[0]);
	}
	exit(0);
}
