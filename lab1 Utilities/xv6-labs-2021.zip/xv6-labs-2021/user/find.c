#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

void find(const char* path,char* name)
{
	char buf[512]={0},*p;
	int fd;
	struct dirent de;
	struct stat st;

	fd = open(path,0);
	strcpy(buf,path);
	p=buf+strlen(buf);
	*p++='/';
	while(read(fd,&de,sizeof(de))==sizeof(de))
	{
		if(de.inum==0||strcmp(de.name,"..")==0||strcmp(de.name,".")==0)
			continue;
		//printf("%s\n",de.name);
		memmove(p,de.name,512);
		p[511]=0;
		stat(buf,&st);
		if(st.type == T_FILE && strcmp(de.name,name)==0)
			printf("%s\n",buf);
		else if(st.type == T_DIR )
			find(buf,name);
	}
	close(fd);
	return;
}



int
main(int argc, const char* argv[])
{
	if(argc > 3)
	{	
		fprintf(2,"find: too many parameters\n");
		exit(1);
	}
	else if(argc<3)
	{	
		fprintf(2,"find: too little parameters\n");
		exit(1);	
	}
	char name[512]={0};
	strcpy(name, argv[2]);
	find(argv[1],name);
	exit(0);
}
