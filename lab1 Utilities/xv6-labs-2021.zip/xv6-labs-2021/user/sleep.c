#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, const char *argv[])
{
	int i = argc;
	if(i>2)
	{
		fprintf(2,"Sleep: too many parameters\n");
		exit(1);
	}
	else if(i<2)
	{
		fprintf(2,"Sleep: missing parameter\n");
		exit(1);
	}
	else
	{
		sleep(atoi(argv[1]));
	}
	exit(0);
}
